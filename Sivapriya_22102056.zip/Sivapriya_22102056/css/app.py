from flask import Flask, render_template, request
import psycopg2

app = Flask(__name__)

# Route to render the form
@app.route('/')
def index():
    return render_template('index.html')

# Route to handle form submission
@app.route('/submit', methods=['POST'])
def submit():
    if request.method == 'POST':
        # Get data from the form
        Username = request.form['Username']
        Password = request.form['Password']
        
        try:
            # Connect to PostgreSQL database
            conn = psycopg2.connect(
                host='localhost',
                database='Sivapriya_22102056',
                user='postgres',
                password='siva@2003'
            )
            cur = conn.cursor()
            
            # Insert data into the database
            cur.execute('INSERT INTO login_page VALUES (%s, %s)', (Username, Password))
            
            # Commit changes and close connection
            conn.commit()
            cur.close()
            conn.close()
            
            return 'Data submitted successfully'
        
        except Exception as e:
            return str(e)

if __name__ == '__main__':
    app.run(debug=True)
